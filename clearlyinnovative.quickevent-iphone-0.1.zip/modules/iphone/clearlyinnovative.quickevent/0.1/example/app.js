/**
* 2011 - Clearly Innovative Inc
*
* QuickEvent Example Code
*
* blog.celarlyinnovative.com
*/
var tabGroup = Titanium.UI.createTabGroup();

var baseWindow = Titanium.UI.createWindow({
    title : "Test",
    backgroundColor : 'white',
    top : 0,
    left : 0,
    width : '100%',
    height : '100%'
});

var tab1 = Titanium.UI.createTab({
    icon : 'KS_nav_views.png',
    title : 'Add Event Test',
    window : baseWindow
});

// TODO: write your module tests here
var quickeventMgr = require('clearlyinnovative.quickevent');

Ti.API.info("module is => " + quickevent);

var quickevent = quickeventMgr.create();

baseWindow.addEventListener('open', function() {
    quickevent.addEvent({
	    "dateFormat" : "yyyy/MM/dd hh:mm a", // default format is MMM dd yyyy HH:mm, like  Oct 21 2011 10:00
        "startDate" : "2011/11/01 10:00 am",
        "endDate" : "2011/11/01 10:30 pm",
        //"timeZone" : "EST", // can be specified or used system default
        "location" : "Times Square NYC",
        "title" : "Test Quick Event Title"
    });
});

tabGroup.addTab(tab1);

// open tab group
tabGroup.open();


quickevent.addEventListener('cancel', function(e){
	Ti.API.info( JSON.stringify(e));
});

quickevent.addEventListener('success', function(e){
	Ti.API.info( JSON.stringify(e));	
});